import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Row, Col, Form, Input, Button } from 'antd';

import { useDispatch } from 'react-redux';
import { AuthFormWrap } from './style';
import { register } from '../../redux/authentication/actionCreator';
import { Checkbox } from '../checkbox/checkbox';

const SignUp = () => {
  const dispatch = useDispatch();

  const [state, setState] = useState({
    values: null,
    checked: null,
  });
  const handleSubmit = (values) => {
    console.log(values);
    dispatch(register(values));
  };

  const onChange = (checked) => {
    setState({ ...state, checked });
  };

  const validatePassword = (_, value) => {
    if (!value) {
      return Promise.reject(new Error('Please input your password!'));
    } else if (value.length < 8) {
      return Promise.reject(
        new Error('Password must be at least 8 characters long!')
      );
    } else if (!/[A-Za-z]/.test(value) || !/[0-9]/.test(value)) {
      return Promise.reject(
        new Error('Password must include both letters and numbers!')
      );
    } else {
      return Promise.resolve();
    }
  };

  const validateConfirmPassword = ({ getFieldValue }) => ({
    validator(_, value) {
      if (value && getFieldValue('password1') !== value) {
        return Promise.reject(new Error('Passwords do not match!'));
      } else {
        return Promise.resolve();
      }
    },
  });

  return (
    <Row justify="center">
      <Col xxl={6} xl={8} md={12} sm={18} xs={24}>
        <AuthFormWrap>
          <div className="ninjadash-authentication-top">
            <h2 className="ninjadash-authentication-top__title">
              Sign Up HexaDash
            </h2>
          </div>
          <div className="ninjadash-authentication-content">
            <Form name="register" onFinish={handleSubmit} layout="vertical">
              <Form.Item
                label="Full Name"
                name="username"
                rules={[
                  { required: true, message: 'Please input your Full name!' },
                  {
                    pattern: /^[A-Za-z]+$/,
                    message: 'Name must contain only letters!',
                  },
                  {
                    min: 2,
                    max: 50,
                    message: 'Name must be between 2 and 50 characters!',
                  },
                ]}>
                <Input placeholder="Full name" />
              </Form.Item>
              <Form.Item
                name="email"
                label="Email Address"
                rules={[
                  {
                    required: true,
                    message: 'Please input your email!',
                    type: 'email',
                  },
                ]}>
                <Input placeholder="name@example.com" />
              </Form.Item>
              <Form.Item
                label="Password"
                name="password1"
                rules={[{ required: true, validator: validatePassword }]}>
                <Input.Password placeholder="Password" />
              </Form.Item>
              <Form.Item
                label="Confirm Password"
                name="password2"
                dependencies={['password1']}
                rules={[
                  { required: true, message: 'Please input your password!' },
                  validateConfirmPassword,
                ]}>
                <Input.Password placeholder="Confirm Password" />
              </Form.Item>
              <div className="ninjadash-auth-extra-links">
                <Checkbox onChange={onChange} checked={state.checked}>
                  Creating an account means you’re okay with our Terms of
                  Service and Privacy Policy
                </Checkbox>
              </div>
              <Form.Item>
                <Button
                  className="btn-create"
                  htmlType="submit"
                  type="primary"
                  size="large"
                  disabled={!state.checked}>
                  Create Account
                </Button>
              </Form.Item>
            </Form>
          </div>
          <div className="ninjadash-authentication-bottom">
            <p>
              Already have an account?<Link to="/login">Sign In</Link>
            </p>
          </div>
        </AuthFormWrap>
      </Col>
    </Row>
  );
};

export default SignUp;
