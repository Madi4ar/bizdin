import axios from 'axios';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const axiosCustom = axios.create({
  baseURL: `${window.location.origin + '/api'}`,
});

const AxiosInterceptor = ({ children }) => {
  const { push, locale } = useRouter();
  const { data } = useSession();

  useEffect(() => {
    if (locale && data) {
      const eventHandlerFn = (config) => {
        config.headers['locale'] = locale;
        config.headers['domain'] = data?.user?.domain;
        return config;
      };

      const interce = axiosCustom.interceptors.request.use(eventHandlerFn);
      return () => {
        axiosCustom.interceptors.request.eject(interce);
      };
    }
    // axios.interceptors.request.use((config) => {
    //   config.headers['locale'] = locale;
    //   return config;
    // });
  }, [locale, data]);

  return children;
};

export { AxiosInterceptor, axiosCustom };
