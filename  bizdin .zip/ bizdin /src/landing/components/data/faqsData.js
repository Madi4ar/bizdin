const faqsData = [
  {
    question: 'What is bizdin ai?',
    answer:
      'We are bizdin ai, an innovative company specializing in the development and implementation of artificial intelligence. Our mission is to improve security and automate the control of order in public and private places using advanced artificial intelligence technologies.',
  },
  {
    question: 'How does bizdin ai work?',
    answer:
      'Our technology uses advanced artificial intelligence algorithms to analyze real-time video streams from surveillance cameras. We develop models capable of recognizing and classifying different events and activities such as littering, theft or traffic accidents.',
  },
  {
    question: 'What is bizdin ai for?',
    answer:
      'bizdin ai is needed to increase security and control in various environments such as public places, shopping centers, office buildings, parking lots and roads.',
  },
  {
    question: 'How do I become a member of the bizdin ai?',
    answer: 'Submit a request by clicking on the "Join waitlist" button.',
  },
];

export default faqsData;
